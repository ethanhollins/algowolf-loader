import setuptools
from Cython.Build import cythonize

__version__ = '0.1.54'

with open('README.md', 'r') as fh:
	long_description = fh.read()

with open('requirements.txt', 'r') as fh:
	requirements = fh.read().split('\n')
	
setuptools.setup(
	name='pythonsdk',
	version=__version__,
	author='Ethan Hollins',
	author_email='ethanjohol@gmail.com',
	description='Systematic trading python sdk',
	long_description=long_description,
	long_description_content_type='text/markdown',
	url='https://github.com/ethanhollins/algowolf-pythonsdk.git',
	packages=setuptools.find_packages(),
	classifiers=[
		"Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
	],
	install_requires=requirements,
	entry_points='''
		[console_scripts]
		pythonsdk=pythonsdk:app
	''',
	python_requires='>=3.6',
	# ext_modules = cythonize('pythonsdk/app/backtester_opt.pyx')
)