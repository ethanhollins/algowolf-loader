
class TradelibException(Exception):
	pass

class BrokerlibException(Exception):
	pass

class OrderException(Exception):
	pass

class BrokerException(Exception):
	pass

class DataLoaderException(Exception):
	pass
